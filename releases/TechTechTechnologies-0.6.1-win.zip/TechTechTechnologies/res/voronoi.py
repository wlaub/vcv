import panel

import sys
import math

from scipy.spatial import Voronoi, voronoi_plot_2d

from matplotlib import pyplot as plt

infile = sys.argv[1]
p = panel.Panel(infile)
p.process_all()

for kind in ['param', 'output', 'light', 'input']:
    count = len(list(filter(lambda x: x.kind==kind, p.controls)))
    print(f'{kind}\t{count}')

points = []
for ctrl in p.controls:
    points.append(ctrl.pos)

plt.figure(figsize=[330/75, 380/75], dpi=75)

vor = Voronoi(points)

voronoi_plot_2d(vor, show_vertices=False, ax=plt.gca())
plt.xlim([0,330])
plt.ylim([0,380])
plt.show()

